import { google } from "googleapis"
import { JWT } from "google-auth-library"

// Create a JWT auth client
const getAuthClient = () => {
  const clientEmail = process.env.GOOGLE_CLIENT_EMAIL
  const privateKey = process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, "\n")

  if (!clientEmail || !privateKey) {
    throw new Error("Missing Google API credentials in environment variables")
  }

  return new JWT({
    email: clientEmail,
    key: privateKey,
    scopes: ["https://www.googleapis.com/auth/calendar", "https://www.googleapis.com/auth/spreadsheets"],
  })
}

// Calendar API
export const getCalendarClient = async () => {
  const auth = getAuthClient()
  return google.calendar({ version: "v3", auth })
}

// Sheets API
export const getSheetsClient = async () => {
  const auth = getAuthClient()
  return google.sheets({ version: "v4", auth })
}

// Create calendar event without sending invitations or creating Meet links
export async function createCalendarEvent(
  summary: string,
  description: string,
  startDateTime: string,
  endDateTime: string,
  attendeeEmail: string,
  attendeeName: string,
  location?: string,
) {
  const calendarId = process.env.GOOGLE_CALENDAR_ID
  if (!calendarId) {
    throw new Error("GOOGLE_CALENDAR_ID environment variable is not set")
  }

  const calendar = await getCalendarClient()

  // Log the exact date-time strings being used
  console.log(`Creating calendar event with start: ${startDateTime}`)
  console.log(`Creating calendar event with end: ${endDateTime}`)

  // Create the event object with necessary details
  // Note: We're not adding attendees to avoid sending invitations
  const event = {
    summary,
    description,
    location: location || "Buzău, România",
    start: {
      dateTime: startDateTime,
      timeZone: "Europe/Bucharest",
    },
    end: {
      dateTime: endDateTime,
      timeZone: "Europe/Bucharest",
    },
    // Add color based on service type (can be customized)
    colorId: "1", // Default blue color
    // Set reminders
    reminders: {
      useDefault: false,
      overrides: [
        { method: "popup", minutes: 60 }, // 1 hour before
      ],
    },
    // Store client info in extended properties instead of as attendees
    extendedProperties: {
      private: {
        clientName: attendeeName,
        clientEmail: attendeeEmail,
      },
    },
  }

  try {
    // Insert the event without sending notifications
    const response = await calendar.events.insert({
      calendarId,
      requestBody: event,
      sendUpdates: "none", // Don't send any notifications
    })

    // Log the created event details
    console.log(`Event created successfully. Event details:`, {
      id: response.data.id,
      summary: response.data.summary,
      start: response.data.start,
      end: response.data.end,
    })

    return response.data
  } catch (error) {
    console.error("Error creating calendar event:", error.message)

    if (error.response) {
      console.error("Error response data:", JSON.stringify(error.response.data, null, 2))
    }

    throw error
  }
}

// Save contact to Google Sheets
export async function saveContactToSheet(name: string, email: string, phone: string, subject: string, message: string) {
  try {
    const sheetId = process.env.GOOGLE_SHEET_ID
    if (!sheetId) {
      throw new Error("GOOGLE_SHEET_ID environment variable is not set")
    }

    const sheets = await getSheetsClient()
    const timestamp = new Date().toISOString()
    const values = [[timestamp, name, email, phone, subject, message]]

    return sheets.spreadsheets.values.append({
      spreadsheetId: sheetId,
      range: "Contacts!A:F",
      valueInputOption: "RAW",
      requestBody: { values },
    })
  } catch (error) {
    console.error("Error saving contact to sheet:", error)
    throw error
  }
}

// Save booking to Google Sheets
export async function saveBookingToSheet(
  name: string,
  email: string,
  phone: string,
  service: string,
  date: string,
  time: string,
  eventId?: string,
) {
  try {
    const sheetId = process.env.GOOGLE_SHEET_ID
    if (!sheetId) {
      throw new Error("GOOGLE_SHEET_ID environment variable is not set")
    }

    const sheets = await getSheetsClient()
    const timestamp = new Date().toISOString()
    // Include the Google Calendar event ID for reference
    const values = [[timestamp, name, email, phone, service, date, time, eventId || "Not created"]]

    return sheets.spreadsheets.values.append({
      spreadsheetId: sheetId,
      range: "Bookings!A:H", // Updated to include eventId column
      valueInputOption: "RAW",
      requestBody: { values },
    })
  } catch (error) {
    console.error("Error saving booking to sheet:", error)
    throw error
  }
}

// Add this new function after the other save functions

// Save newsletter subscription to Google Sheets
export async function saveNewsletterSubscription(email: string) {
  try {
    const sheetId = process.env.GOOGLE_SHEET_ID
    if (!sheetId) {
      throw new Error("GOOGLE_SHEET_ID environment variable is not set")
    }

    const sheets = await getSheetsClient()
    const timestamp = new Date().toISOString()
    const values = [[timestamp, email, "Website Newsletter"]]

    return sheets.spreadsheets.values.append({
      spreadsheetId: sheetId,
      range: "Newsletter!A:C", // Make sure this sheet exists in your Google Sheets
      valueInputOption: "RAW",
      requestBody: { values },
    })
  } catch (error) {
    console.error("Error saving newsletter subscription to sheet:", error)
    throw error
  }
}

// Get available time slots with improved handling
export async function getAvailableTimeSlots(date: string, serviceType?: string) {
  try {
    const calendarId = process.env.GOOGLE_CALENDAR_ID
    if (!calendarId) {
      throw new Error("GOOGLE_CALENDAR_ID environment variable is not set")
    }

    const calendar = await getCalendarClient()

    // FIXED: Parse the date components correctly
    const [year, month, day] = date.split("-").map((num) => Number.parseInt(num, 10))

    // Log the parsed date components for debugging
    console.log(`Checking availability for date: ${date} (${year}-${month}-${day})`)

    // FIXED: Create date strings for the exact day in Romania timezone
    // The key fix: Use the correct date with the Romania timezone offset
    const startDateStr = `${date}T00:00:00+03:00`
    const endDateStr = `${date}T23:59:59+03:00`

    console.log(`Start date string: ${startDateStr}`)
    console.log(`End date string: ${endDateStr}`)

    // Get busy slots from calendar using the RFC3339 timestamp strings directly
    const response = await calendar.freebusy.query({
      requestBody: {
        timeMin: startDateStr,
        timeMax: endDateStr,
        timeZone: "Europe/Bucharest",
        items: [{ id: calendarId }],
      },
    })

    // Define business hours and slot duration
    const businessHours = {
      start: 10, // 10:00 AM
      end: 18, // 6:00 PM
    }

    // Get the duration based on service type (default to the longest if not specified)
    const durationMinutes = serviceType ? getServiceDuration(serviceType) : 60

    console.log(`Using duration: ${durationMinutes} minutes`)

    // Generate all possible time slots during business hours
    const allPossibleSlots = []
    for (let hour = businessHours.start; hour < businessHours.end; hour++) {
      // Skip lunch break (13:00-14:00)
      if (hour === 13) continue

      allPossibleSlots.push(`${hour.toString().padStart(2, "0")}:00`)
    }

    // Get busy time ranges
    const busySlots = response.data.calendars?.[calendarId]?.busy || []
    console.log(`Found ${busySlots.length} busy slots for ${date}`)

    if (busySlots.length > 0) {
      busySlots.forEach((slot) => {
        console.log(`Busy slot: ${slot.start} to ${slot.end}`)
      })
    }

    // Filter out busy slots with improved overlap detection
    const availableSlots = allPossibleSlots.filter((slot) => {
      // For each potential slot, create start and end times with explicit timezone
      const [hours, minutes] = slot.split(":").map((num) => Number.parseInt(num, 10))

      // Create RFC3339 timestamp strings for the slot start and end
      const slotStartStr = `${date}T${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:00+03:00`
      const slotEndTime = new Date(new Date(slotStartStr).getTime() + durationMinutes * 60 * 1000)
      const slotEndStr = slotEndTime.toISOString()

      // Check if this slot overlaps with any busy period
      const isOverlapping = busySlots.some((busy) => {
        const busyStart = new Date(busy.start)
        const busyEnd = new Date(busy.end)
        const slotStart = new Date(slotStartStr)
        const slotEnd = new Date(slotEndStr)

        // Check for any overlap between the slot and the busy period
        return (
          (slotStart < busyEnd && slotEnd > busyStart) ||
          // Also check if the slot would end too close to the next appointment (15-minute buffer)
          (slotEnd > busyStart && slotEnd <= new Date(busyStart.getTime() + 15 * 60 * 1000))
        )
      })

      return !isOverlapping
    })

    console.log(`Available slots for ${date}: ${availableSlots.join(", ")}`)
    return availableSlots
  } catch (error) {
    console.error("Error fetching available time slots:", error)
    // Return default slots on error
    return ["10:00", "11:00", "12:00", "14:00", "15:00", "16:00", "17:00"]
  }
}

// Helper function to determine service duration
function getServiceDuration(serviceValue: string): number {
  switch (serviceValue) {
    case "initial":
      return 30 // 30 minutes
    case "nutrition":
    case "training":
      return 45 // 45 minutes
    case "competition":
      return 60 // 60 minutes
    default:
      return 60 // default to 60 minutes to be safe
  }
}

